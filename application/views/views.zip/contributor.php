<div class="main" role="main">
  <section class="section section-register m-0 border-0">
    <div class="container">
      <div class="row no-gutters register-box">
        <div class="col"></div>
        <div class="col p-5">
          <h4>Menjadi <strong>Contributor</strong></h4>
          <form class="" action="<?php echo base_url().'member/register_act' ?>" method="post">
            <div class="form-group">
              <input class="form-control" type="text" name="nama" value="" placeholder="Nama Kelas" required="required">
              <?php echo form_error('nama'); ?>
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="email" value="" placeholder="Category Kelas" required="required">
              <?php echo form_error('email'); ?>
            </div>
            <div class="form-group">
              <input class="form-control" type="password" name="password" value="" placeholder="Profile Mentor" required="required">
              <?php echo form_error('password'); ?>
            </div>
            <div class="form-group">
              
              <input class="" type="file" name="kode_ref" value="Upload Photo" placeholder="">
              <!--  -->
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="kode_ref" value="" placeholder="Alamat">
              <!--  -->
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="kode_ref" value="" placeholder="No Rekening">
              <!--  -->
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="kode_ref" value="" placeholder="Bank Rekening">
              <!--  -->
            </div>
            <div class="form-group">
              <justify>
              <input type='checkbox' class="text-justify" for="" required="required">Ya Saya ingin mendapatkan manfaat maksimal dari Artademi dengan email yang berisi penawaran eksklusif, rekomendasi pribadi, dan tips pembelanjaan</label>
            </justify>
            <!-- <input type="submit" value="Daftar" class="btn btn-warning btn-rounded btn-modern btn-blocky"> -->
              <button type="submit" class="btn btn-warning btn-rounded btn-modern btn-block" type="button" name="">Daftar</button>
              <label class="text-center text-warning d-block" for="">Dengan mendaftar, anda menyetuji ketentuan penggunaan dan kebijakan privasi</label> 
               <label class="text-center text-warning d-block" for=""> Sudah punya akun ?<a href="daftar.php" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-1-30">Login</label> 
            </div>
          </form>
          <form action="<?php echo base_url().'home' ?>" method="post" enctype="multipart/form-data">
        </div>
      </div>
    </div>
  </section>
</div> 
