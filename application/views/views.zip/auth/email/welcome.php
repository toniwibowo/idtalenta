<html>
<body>
	<h1>Hello <?php echo $fullname ?></h1>
	<p>Thank you for registering at Studentpreneur Course. Your account details are as follows:</p>
	<table>
		<tr>
			<td>Full name : </td>
			<td><?php echo $fullname ?></td>
		</tr>
		<tr>
			<td>Email : </td>
			<td><?php echo $email ?></td>
		</tr>
		<tr>
			<td>Password : </td>
			<td><?php echo $password ?></td>
		</tr>
	</table>
</body>
</html>