<content>
  <section>
    <div class="container">
      <div class="clearer cellpadding">
        <nav aria-label="breadcrumb">
          <ul class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Home</a>
            </li>
            <li class="breadcrumb-item active">
              Reference
            </li>
          </ul>
        </nav>

        <div class="section-header wow fadeInUp mb-4">
        <h3>Reference</h3>
        <p>Berikut ini adalah daftar our partners dari PT Indosan Berkat Bersama</p>
        </div>

        <div class="row">
          <div class="col-md-3 col-12">
            <figure class="figure">
              <img class="img-fluid mb-3" src="<?php echo base_url('assets/uploads/files/0231f-partners1.jpg') ?>" alt="">
              <figcaption class="figure-caption">
                <h4>PT Sukses Dinamika Lestari</h4>
              </figcaption>
            </figure>
          </div>

          <div class="col-md-3 col-12">
            <figure class="figure">
              <img class="img-fluid mb-3" src="<?php echo base_url('assets/uploads/files/0231f-partners1.jpg') ?>" alt="">
              <figcaption class="figure-caption">
                <h4>PT Sukses Dinamika Lestari</h4>
              </figcaption>
            </figure>
          </div>

          <div class="col-md-3 col-12">
            <figure class="figure">
              <img class="img-fluid mb-3" src="<?php echo base_url('assets/uploads/files/0231f-partners1.jpg') ?>" alt="">
              <figcaption class="figure-caption">
                <h4>PT Sukses Dinamika Lestari</h4>
              </figcaption>
            </figure>
          </div>

          <div class="col-md-3 col-12">
            <figure class="figure">
              <img class="img-fluid mb-3" src="<?php echo base_url('assets/uploads/files/0231f-partners1.jpg') ?>" alt="">
              <figcaption class="figure-caption">
                <h4>PT Sukses Dinamika Lestari</h4>
              </figcaption>
            </figure>
          </div>
        </div>

      </div>
    </div>
  </section>
</content>
