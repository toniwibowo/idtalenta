<div class="container">
	<div class="row">
		<div class="col-lg-10 col-lg-offset-1">			
			<div class="box">
				<div class="box-header">
					<h1><?php echo $content->title ?></h1>
				</div><!-- /.box-header -->
				<div class="box-body">
					<?php echo $content->content ?>
				</div><!-- /.box-body -->
			</div>
		</div>	
	</div>
</div>
