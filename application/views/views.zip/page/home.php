
<section>
	<div class="container">
		
		<div class="row list-videos">
				

				<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/WSinMOs5eGw">
					<img src="https://i.ytimg.com/vi/WSinMOs5eGw/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Golden boy Calum Scott hits the </span>
						<br>
						<small style="color:gray">Britain's Got Talent</small>
					</div>
				</a>
			</div>
		</div>
								<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/_wYtG7aQTHA">
					<img src="https://i.ytimg.com/vi/_wYtG7aQTHA/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Steven Spielberg vs Alfred Hitch</span>
						<br>
						<small style="color:gray">ERB</small>
					</div>
				</a>
			</div>
		</div>
								
		<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/WSinMOs5eGw">
					<img src="https://i.ytimg.com/vi/WSinMOs5eGw/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Golden boy Calum Scott hits the </span>
						<br>
						<small style="color:gray">Britain's Got Talent</small>
					</div>
				</a>
			</div>
		</div>


		</div>



		<div class="row list-videos">
				

				<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/WSinMOs5eGw">
					<img src="https://i.ytimg.com/vi/WSinMOs5eGw/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Golden boy Calum Scott hits the </span>
						<br>
						<small style="color:gray">Britain's Got Talent</small>
					</div>
				</a>
			</div>
		</div>
								<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/_wYtG7aQTHA">
					<img src="https://i.ytimg.com/vi/_wYtG7aQTHA/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Steven Spielberg vs Alfred Hitch</span>
						<br>
						<small style="color:gray">ERB</small>
					</div>
				</a>
			</div>
		</div>
								
		<div class="col-sm-4 col-xs-3">
			<div class="thumbnail">
				<a href="/video/WSinMOs5eGw">
					<img src="https://i.ytimg.com/vi/WSinMOs5eGw/mqdefault.jpg" class="img-responsive">
					<div class="caption">
						<span>Golden boy Calum Scott hits the </span>
						<br>
						<small style="color:gray">Britain's Got Talent</small>
					</div>
				</a>
			</div>
		</div>


		</div>


	</div>
</section>