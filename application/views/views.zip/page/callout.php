<div class="callout callout-success">
	<h4><?php echo $content->title ?></h4>
	<?php echo $content->content ?>
</div>