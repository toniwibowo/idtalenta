<div class="main" role="main">
  <section class="section section-register m-0 border-0">
    <div class="container">
      <div class="row no-gutters register-box">
        <div class="col"></div>
        <div class="col p-5">
          <h4>Daftar ke <strong>ARTAdemi</strong></h4>
          <form class="" action="<?php echo base_url().'member/register_act' ?>" method="post">
            <div class="form-group">
              <input class="form-control" type="text" name="nama" value="" placeholder="Nama Lengkap" required="required">
              <?php echo form_error('nama'); ?>
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="email" value="" placeholder="Email" required="required">
              <?php echo form_error('email'); ?>
            </div>
            <div class="form-group">
              <input class="form-control" type="password" name="password" value="" placeholder="Password" required="required">
              <?php echo form_error('password'); ?>
            </div>
            <div class="form-group">
              <input class="form-control" type="text" name="kode_ref" value="" placeholder="Kode Refreal">
              <!--  -->
            </div>
            <div class="form-group">
               <justify>
              <input type='checkbox' class="text-justify" for="">Ya Saya ingin mendapatkan manfaat maksimal dari Artademi dengan email yang berisi penawaran eksklusif, rekomendasi pribadi, dan tips pembelanjaan</label>
            
            <!-- <input type="submit" value="Daftar" class="btn btn-warning btn-rounded btn-modern btn-blocky"> -->
              <button type="submit" class="btn btn-warning btn-rounded btn-modern btn-block" type="button" name="">Daftar</button>
              <label class="text-center text-warning d-block" for="">Dengan mendaftar, anda menyetuji ketentuan penggunaan dan kebijakan privasi</label> 
             </justify>
                <center><label type='' class="text-justify" for="">Sudah Punya Akun ?</label></center>
              <button class="btn btn-info btn-rounded btn-modern btn-block" type="button" name="button">Login</button>

            </div>
          </form action="<?php echo base_url().'home' ?>" method="post" enctype="multipart/form-data">
        </div>
      </div>
    </div>
  </section>
</div> 
