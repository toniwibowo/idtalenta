<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class mentor extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index()
  {
    // $this->load->helper('url');
    $this->load->view('include/header');
    $this->load->view('mentor');
    $this->load->view('include/footer');
  }

  

  public function dashboard()
  {
    $this->load->view('include/header');
    $this->load->view('mentor-dashboard');
    $this->load->view('include/footer');
  }

}
