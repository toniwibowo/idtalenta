<?php
  if(!defined('BASEPATH'))
    exit('No direct script access allowed');

  class Subscribe extends CI_Controller
  {

    public function __construct()
    {
      parent::__construct();
    }

        function index(){
        $email = $this->input->post("email");
            header('Content-Type: application/x-json; charset=utf-8');
            $this->db->set('email',"$email");
            $this->db->insert('subscribe');
            $insert = $this->db->insert_id();
            echo(json_encode($insert));
        }
    public function add_new(){
            $email = $this->input->post("email");
            header('Content-Type: application/x-json; charset=utf-8');
            $this->db->set('email',"$email");
            $this->db->insert('subscribe');
            $insert = $this->db->insert_id();
            echo(json_encode($insert));
        }


  }